var player, player_running;
var banana;
var obstacleGroup;
var score = 0;
var backImage;
var ground;



function preload(){
backimage = loadImage("jungle.jpg");
  
  player_running = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  
  
  bananaImage = loadImage("Banana.png");
  
  obstacleImage = loadImage("stone.png");
                                 


}
function setup() {
  createCanvas(400, 400);
  var backdrop = createSprite(200,200,400,400);
  backdrop.addAnimation("jungle.jpg", backImage);
  backdrop = ground.width/2;
  backdrop.velocityX = -4;

}

function draw() {
  background(220);
}